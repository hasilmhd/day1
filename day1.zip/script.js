// console.log("hello")

// var a = "hello"
// console.log(a)

// {
//     console.log(a)
// }
// {
//     var a = 10
//     console.log(a)
//  a = 20
//     console.log(a)
// }
// console.log(a)


// const array1=[1,2,3]
// const array2=[4,5,6]
// const array3 = [...array1, ...array2]
// console.log(array3)

const person = {
    name: "deepak",
    age: "28",
    place:"thamarassery"
}
console.log(person.name,person.age,person.place)